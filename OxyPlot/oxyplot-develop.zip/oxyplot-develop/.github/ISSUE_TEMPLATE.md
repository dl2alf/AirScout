*IF BUG, INCLUDE THIS PART:*

### Steps to reproduce

1.
2.
3.

Platform:
.NET version:

### Expected behaviour

Tell us what should happen

### Actual behaviour

Tell us what happens instead
Can you also include a screen shot?



*IF IT IS A NEW FEATURE REQUEST, INCLUDE THIS PART:*

### Feature description

Write a description of the feature. How should it work? How should it look?
Include some graphics if this could help!

